<h1>Hello World!!!</h1>
<h3>PHP Version <?= phpversion() ?></h3>
<a href="/static.html">Static HTML Page</a>